mr3-run-k8s
===========
Code for running Hive/Spark on MR3 on Kubernetes

  /kubernetes - Executable scripts with YAML files

  /typescript - TypeScript code for generating YAML files

For instructions, visit:

  https://mr3docs.datamonad.com/docs/quick/k8s/ 

