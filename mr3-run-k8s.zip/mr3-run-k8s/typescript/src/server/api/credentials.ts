export interface T {
  kubeConfig?: string;
}

