#!/bin/bash

export HADOOP_CREDSTORE_PASSWORD=${env.secret.sslPassword}

