#!/bin/bash

export SERVER_THREADS_AMOUNT=8

