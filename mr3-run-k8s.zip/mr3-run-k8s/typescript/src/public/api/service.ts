export interface T {
  namespace: string;
  useHttps: boolean;
}
