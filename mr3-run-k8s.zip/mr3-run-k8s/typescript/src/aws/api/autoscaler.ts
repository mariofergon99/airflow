export interface T {
  autoscalingScaleDownDelayAfterAddMin: number;
  autoscalingScaleDownUnneededTimeMin: number;

  //
  // to be set in validate()
  //
}
