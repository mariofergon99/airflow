export interface T {
  efsId: string;
}

